//
//  NoteDetailViewController.swift
//  JTSBoard
//
//  Created by jts on 02/08/18.
//  Copyright © 2018 jts. All rights reserved.
//

import UIKit
import SwiftyJSON

class NoteDetailViewController: UIViewController,UITableViewDelegate,UITableViewDataSource,WebServiceControllerDelegate, UIImagePickerControllerDelegate, UINavigationControllerDelegate,UIPickerViewDelegate,UIPickerViewDataSource,UITextFieldDelegate,UITextViewDelegate  {
   
    
    var pickerView:UIPickerView!
    var objWebServiceController: WebServiceController?

    @IBOutlet weak var tblService: UITableView!
    @IBOutlet weak var scrollView: UIScrollView!

    @IBOutlet weak var btnAddService: UIButton!
    @IBOutlet weak var txtNote: UITextView!
    @IBOutlet weak var btnSubmit: UIButton!
    @IBOutlet weak var btnUploadImage: UIButton!
    
    @IBOutlet weak var tblServieHeight: NSLayoutConstraint!
    @IBOutlet weak var serviceView: UIView!
    @IBOutlet weak var imgNote: UIImageView!
    @IBOutlet weak var imgNoteHeight: NSLayoutConstraint!
    
    var arrServiceList:NSMutableArray! = NSMutableArray()
    var arrServiceTextfield:NSMutableArray! = NSMutableArray()
    var arrSalonServices:NSMutableArray! = NSMutableArray()
    var arrPaymentMethod:NSMutableArray! = NSMutableArray()

    let picker = UIImagePickerController()
    let serviceIdentifier = "addservicecell"
    var cell: AddServiceTableViewCell!
    
    var serviceCount:Int!
    var customerId:String!
    var currentDate:String!
    var dateId:String!
    var uploadedNoteImage:String!

    var pickerType:String!
    var keypadType:String!
    var isBackSpace:Bool!

    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        
        // Do any additional setup after loading the view.
    }
    
    override func viewDidAppear(_ animated: Bool) {
        
        
            self.objWebServiceController = WebServiceController()
            self.objWebServiceController?.delegate = self
            
            self.arrSalonServices.add("ネイル")
            self.arrSalonServices.add("フェイシャル")
            self.arrSalonServices.add("アイラッシュ")
            self.arrSalonServices.add("ボディ")
            self.arrSalonServices.add("脱毛")
            
            self.arrPaymentMethod.add("現金")
            self.arrPaymentMethod.add("カード")
            self.arrPaymentMethod.add("切符売場")
       

            
            serviceCount = 1;
            picker.delegate = self
            
            self.tblServieHeight.constant = 0
            self.tblService.isHidden = true
            self.serviceView.isHidden = true
            
            self.imgNoteHeight.constant = 0
            self.imgNote.isHidden = true
            
            
            self.txtNote.layer.cornerRadius = 5.0
            self.imgNote.layer.cornerRadius = 5.0
            self.btnSubmit.layer.cornerRadius = 5.0
            
            
            self.tblService.register(UINib(nibName: "AddServiceTableViewCell", bundle: nil), forCellReuseIdentifier: serviceIdentifier)
            
            self.tblServieHeight.constant = CGFloat((self.arrServiceList.count + serviceCount) * 220)
            self.tblService.isHidden = false
            self.serviceView.isHidden = false
            if self.dateId != "" {
                
                self.getCustomerServiceDetail()
            }
        NotificationCenter.default.addObserver(self, selector: #selector(NoteDetailViewController.keyboardWillShow), name: NSNotification.Name.UIKeyboardWillShow, object: nil)
        
        NotificationCenter.default.addObserver(self, selector: #selector(NoteDetailViewController.keyboardWillHide), name: NSNotification.Name.UIKeyboardWillHide, object: nil)

    }
   
    func createServicePicker(textField:UITextField)
    {
        var alertTitle:String!
        
        if textField.tag == 2 {
            
            alertTitle = "サービスを選択"
            self.pickerType = "service"
        }
        if textField.tag == 3 {
            
            alertTitle = "払いの種類"
            self.pickerType = "payment"

        }
        let alertView = UIAlertController(
            title: alertTitle,
            message: "\n\n\n\n\n\n\n\n\n",
            preferredStyle: .alert)
        
        self.pickerView = UIPickerView(frame:
            CGRect(x: 0, y: 50, width: 260, height: 162))
        self.pickerView.dataSource = self
        self.pickerView.delegate = self
        
        // comment this line to use white color
        self.pickerView.backgroundColor = UIColor.lightGray.withAlphaComponent(0.2)
        
        
        alertView.view.addSubview(self.pickerView)
        
        let action = UIAlertAction(title: "OK", style: .default, handler: { (alert: UIAlertAction!) -> Void in
            //  Do some action here.
            
            if textField.tag == 2 {

            textField.text =  self.arrSalonServices.object(at: self.pickerView.selectedRow(inComponent: 0)) as? String
            
            }
            else
            {
                textField.text =  self.arrPaymentMethod.object(at: self.pickerView.selectedRow(inComponent: 0)) as? String

            }
        })

        self.pickerView.selectRow(1, inComponent: 0, animated: true)

        alertView.addAction(action)
        self.present(alertView, animated: true) {
            
            self.pickerView.frame.size.width = alertView.view.frame.size.width

            
        }
        
      
    }
    func getCustomerServiceDetail()
    {
        ConfigManager.showLoadingHUD(to_view: self.view)
        
        var parameters = [String : AnyObject] ()
        
        parameters["MethodName"] = "get_customer_analysis" as AnyObject
        parameters["user_id"] = ConfigManager.gUserId as AnyObject
        parameters["customer_id"] = self.customerId as AnyObject
        parameters["id"] = self.dateId as AnyObject

        self.objWebServiceController?.serverParameter(parameters: parameters)
        
    }
    func saveServiceDetail()
    {
        ConfigManager.showLoadingHUD(to_view: self.view)
        
      //  print(self.arrServiceList!)
        
        var parameters = [String : AnyObject] ()
        
        parameters["MethodName"] = "customer_analysis" as AnyObject
        parameters["user_id"] = ConfigManager.gUserId as AnyObject
        parameters["customer_id"] = self.customerId as AnyObject
        parameters["service_price"] = self.arrServiceList! as AnyObject
        parameters["note_text"] = self.txtNote.text as AnyObject
        parameters["date"] = self.currentDate as AnyObject
        if self.uploadedNoteImage != nil
        {
            parameters["note_image"] = self.uploadedNoteImage! as AnyObject

        }

        if self.dateId != "" {

             parameters["id"] = self.dateId as AnyObject

        }

        
        print(parameters)
        //self.objWebServiceController?.serverPostImageParameter(parameters: parameters, image: self.imgNote.image!)

        self.objWebServiceController?.serverPostParameter(parameters: parameters)
    }
    @IBAction func btnAddServiceAction(_ sender: UIButton) {
        
        var emptyFlag = false
        
        self.arrServiceList.removeAllObjects()
        self.serviceCount = 1;

        for i in 0..<self.arrServiceTextfield.count {
            
            let service = ((self.arrServiceTextfield.object(at: i)) as! NSDictionary).object(forKey: "service") as! UITextField
            let price = ((self.arrServiceTextfield.object(at: i)) as! NSDictionary).object(forKey: "price") as! UITextField
            let payment = ((self.arrServiceTextfield.object(at: i)) as! NSDictionary).object(forKey: "payment") as! UITextField

            print(service)
            
            if (service.text?.isEmpty)! ||  (price.text?.isEmpty)! || (payment.text?.isEmpty)!
            {
                emptyFlag = true
            }
            else
            {
                var parameters = [String : Any] ()
                
                parameters["service"] = service.text!
                parameters["price"] = price.text!
                parameters["payment"] = payment.text!

                if !(self.arrServiceList.contains(parameters))
                {
                    self.arrServiceList.add(parameters)
                    
                }
                
            }
            
        }
        if emptyFlag == false {
            
            self.tblServieHeight.constant = (CGFloat(self.arrServiceList.count + serviceCount) * 220) + 20
            self.tblService.isHidden = false
            self.tblService.reloadData()
        }
        else
        {
            let alert = UIAlertController(title: "", message: "空の値", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            self.present(alert, animated: true)
        }
        
       // print(self.arrServiceTextfield)
        
    }
   
    @IBAction func btnSubmitAction(_ sender: UIButton) {
        
        self.arrServiceList.removeAllObjects()

        for i in 0..<self.arrServiceTextfield.count {
            
            let service = ((self.arrServiceTextfield.object(at: i)) as! NSDictionary).object(forKey: "service") as! UITextField
            let price = ((self.arrServiceTextfield.object(at: i)) as! NSDictionary).object(forKey: "price") as! UITextField
            let payment = ((self.arrServiceTextfield.object(at: i)) as! NSDictionary).object(forKey: "payment") as! UITextField

            print(service)
            
            if (service.text?.isEmpty)! ||  (price.text?.isEmpty)! ||  (payment.text?.isEmpty)!
            {
            }
            else
            {
                var parameters = [String : Any] ()
                
                parameters["service"] = service.text
                parameters["price"] = price.text
                parameters["payment"] = payment.text

                if !(self.arrServiceList.contains(parameters))
                {
                    self.arrServiceList.add(parameters)
                    
                }
                
            }
            
        }
        
        if self.arrServiceList.count == 0 {
            
            let alert = UIAlertController(title: "", message: "サービスの選択", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            self.present(alert, animated: true)
        
            return
        }
         if self.txtNote.text.count == 0{
            
            let alert = UIAlertController(title: "", message: "メモを入力", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            self.present(alert, animated: true)
            return
        }
        
        
        self.saveServiceDetail()
    }
    
    @IBAction func btnUploadImageAction(_ sender: UIButton) {
        
        let alertController = UIAlertController(title: nil, message: "写真をアップする", preferredStyle: .actionSheet)
        
        let photoLibrary = UIAlertAction(title: "図書館から取る", style: .default, handler: { (alert: UIAlertAction!) -> Void in
            //  Do some action here.
            
                self.picker.allowsEditing = false
                self.picker.delegate = self
                self.picker.sourceType = .photoLibrary
                self.picker.mediaTypes = UIImagePickerController.availableMediaTypes(for: .photoLibrary)!
                self.picker.modalPresentationStyle = .popover
                self.present(self.picker, animated: true, completion: nil)
                self.picker.popoverPresentationController?.sourceView = sender
           

        })
        
        let cemaraAction = UIAlertAction(title: "カマラから取る", style: .destructive, handler: { (alert: UIAlertAction!) -> Void in
            //  Do some destructive action here.
            
            if UIImagePickerController.isSourceTypeAvailable(.camera) {
                self.picker.allowsEditing = false
                self.picker.sourceType = UIImagePickerControllerSourceType.camera
                self.picker.cameraCaptureMode = .photo
                self.picker.modalPresentationStyle = .fullScreen
                self.present(self.picker,animated: true,completion: nil)
            }
        })
        
        let cancelAction = UIAlertAction(title: "キャンセル", style: .cancel, handler: { (alert: UIAlertAction!) -> Void in
            //  Do something here upon cancellation.
        })
        
        alertController.addAction(photoLibrary)
        alertController.addAction(cemaraAction)
        alertController.addAction(cancelAction)
        
        if let popoverController = alertController.popoverPresentationController {
            
            popoverController.sourceView = sender
            
           // popoverController.sourceRect = CGRect(x: self.view.bounds.midX, y: self.view.bounds.midY, width: 0, height: 0)

        }
        self.present(alertController, animated: true, completion: nil)

    }
    
    // MARK: UIimagepicker delegate

    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        let img = info[UIImagePickerControllerOriginalImage] as! UIImage
        
        self.imgNote.image = img
        
        self.imgNoteHeight.constant = 235
        self.imgNote.isHidden = false
        dismiss(animated:true, completion: nil)
        
       // print(self.arrServiceList!)
        
        var parameters = [String : AnyObject] ()
        
        parameters["MethodName"] = "customer_analysis" as AnyObject
      
        parameters["note_image"] = self.uploadedNoteImage as AnyObject
        
        if self.dateId != "" {
            
            parameters["id"] = self.dateId as AnyObject
            
        }
        
        ConfigManager.showLoadingHUD(to_view: self.view)

        print(parameters)
        //self.objWebServiceController?.serverPostImageParameter(parameters: parameters, image: self.imgNote.image!)
        
        self.objWebServiceController?.serverImageParameter(image: img)

    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        
    }

    // MARK: Uitableview delegate

    func numberOfSections(in tableView: UITableView) -> Int {
        
        return 1;
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return self.arrServiceList.count + serviceCount;
        
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        
        return 220;
    }
    func tableView(_ tableView: UITableView, estimatedHeightForRowAt indexPath: IndexPath) -> CGFloat {
        
        return 50.0
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
       
             cell = (tableView.dequeueReusableCell(withIdentifier: serviceIdentifier) as? AddServiceTableViewCell?)!
            
            if cell == nil {
                
                cell = self.tblService.dequeueReusableCell(withIdentifier: serviceIdentifier) as? AddServiceTableViewCell
                
               
            }
            
            if indexPath.row <= (self.arrServiceList.count - 1)
            {
                cell.txtServiceName.text = (self.arrServiceList.object(at: indexPath.row) as! NSDictionary).object(forKey: "service") as? String
                cell.txtPrice.text = (self.arrServiceList.object(at: indexPath.row) as! NSDictionary).object(forKey: "price") as? String
                cell.txtPaymentType.text = (self.arrServiceList.object(at: indexPath.row) as! NSDictionary).object(forKey: "payment") as? String

            }
            else
            {
                cell.txtServiceName.text = ""
                cell.txtPrice.text = ""
                cell.txtPaymentType.text = ""

            }
        cell.txtPrice.addTarget(self, action: #selector(myTextFieldDidchange), for: .editingChanged)

            cell.txtServiceName.delegate = self;
            cell.txtPrice.delegate = self
            cell.txtPaymentType.delegate = self
        
        cell.txtServiceName.tag = 2
        cell.txtPaymentType.tag = 3
        cell.txtPrice.tag = 1

            var parameters = [String : Any] ()
            
            parameters["service"] = cell.txtServiceName!
            parameters["price"] = cell.txtPrice!
            parameters["payment"] = cell.txtPaymentType!

            if !(self.arrServiceTextfield.contains(parameters))
            {
                self.arrServiceTextfield.add(parameters)
                
            }
            
            return cell
     
    }
    // MARK: Webservice delegate

    func serviceImageResponse(forURl urlString: String, response: NSDictionary) {
        
        ConfigManager.hideLoadingHUD(for_view: self.view)
        
        if !(urlString == "server_error_handle") {
            
             if urlString == "upload_note_image"
            {
                if let resData = response["response_data"] {
                    
                    let dict:NSDictionary = resData as! NSDictionary
                    
                    let image:String! = String(describing:dict["image"]!)
                    
                    self.uploadedNoteImage = image!
                    
                    print(self.uploadedNoteImage!);
                    
                }
            }
        }
    }
   
    // MARK: webservice delegate
 
    func serviceResponse(forURl urlString: String, response: JSON) {
        
        ConfigManager.hideLoadingHUD(for_view: self.view)
        
        if !(urlString == "server_error_handle") {
            
            if urlString == "get_customer_analysis"
            {
                if let resData = response["service_price"].arrayObject {
                    
                    self.arrServiceList = (resData as NSArray).mutableCopy() as! NSMutableArray
                }
                if let resData = response["note_text"].string {
                    
                    self.txtNote.text = resData
                }
                if let resData = response["note_image"].string {
                    
                    self.uploadedNoteImage = resData
                    
                    self.uploadedNoteImage = self.uploadedNoteImage.replacingOccurrences(of: ConfigManager.gImageUrl, with: "")
                    
                    let imageFullUrl = ConfigManager.gImageUrl + self.uploadedNoteImage
                   
                    URLSession.shared.dataTask(with: NSURL(string: imageFullUrl)! as URL, completionHandler: { (data, response, error) -> Void in
                        
                        if error != nil {
                            print(error)
                            return
                        }
                        DispatchQueue.main.async(execute: { () -> Void in
                            let image = UIImage(data: data!)
                            self.imgNote.image = image
                            
                            self.imgNoteHeight.constant = 235
                            self.imgNote.isHidden = false
                            
                        })
                        
                    }).resume()
                }
                
                
               // if self.arrServiceList.count > 0
               // {
                self.serviceCount = 0;

                if self.arrServiceList.count == 0
                {
                    self.serviceCount = 1;

                }
                    self.arrServiceTextfield.removeAllObjects()

                    self.tblServieHeight.constant = (CGFloat(self.arrServiceList.count + serviceCount) * 220) + 20
                    self.tblService.isHidden = false
                  
                    self.tblService.delegate = self
                    self.tblService.dataSource = self
                     self.tblService.reloadData()
                    self.scrollView.isHidden = false

                //}
            }
            else if urlString == "customer_analysis"
            {
                let status:String! = String(describing:response["status"])
                let msg:String! = String(describing:response["msg"])

                if msg != nil
                {
                    let alert = UIAlertController(title: "", message: msg, preferredStyle: .alert)
                    alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                    self.present(alert, animated: true)
                    
                }
                if status != nil
                {
                    if status == "success"
                    {
                        self.dismiss(animated: true) {
                            self.navigationController?.popViewController(animated: true)

                        }
                    }
                }
                
            }
            
            
        }
        else {
            let alert = UIAlertController(title: "", message: "Error", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            self.present(alert, animated: true)
        }
    }
  
    // MARK: Picker view delegate

    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        
        return 1
    }
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        
        if self.pickerType == "service"
        {
            return self.arrSalonServices.count

        }
        else
        {
            return self.arrPaymentMethod.count

        }
    }
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        
        
        if self.pickerType == "service"
        {
            return self.arrSalonServices.object(at: row) as? String

        }
        else
        {
            return self.arrPaymentMethod.object(at: row) as? String

        }
    }
   // MARK: Uitextfield delegate
    
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        
        if textField.tag == 2 || textField.tag == 3
        {
            self.createServicePicker(textField: textField)
            textField.resignFirstResponder()
            return false
        }
        else
        {
            return true
        }
    }
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        
        self.keypadType = "textfield"
        
    }
    func textViewDidBeginEditing(_ textView: UITextView) {
        
        self.keypadType = "textview"
        
    }
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        
        textField.resignFirstResponder()
        return true
    }
    @objc func adjustForKeyboard(notification: Notification) {
        let userInfo = notification.userInfo!
        
        let keyboardScreenEndFrame = (userInfo[UIKeyboardFrameEndUserInfoKey] as! NSValue).cgRectValue
        let keyboardViewEndFrame = view.convert(keyboardScreenEndFrame, from: view.window)
        
        if notification.name == Notification.Name.UIKeyboardWillHide {
            self.scrollView.contentInset = UIEdgeInsets.zero
        } else {
            self.scrollView.contentInset = UIEdgeInsets(top: 0, left: 0, bottom: keyboardViewEndFrame.height, right: 0)
        }
        
        self.scrollView.scrollIndicatorInsets = self.scrollView.contentInset
        
        //let selectedRange = self.scrollView.selectedRange
        //self.scrollView.scrollRangeToVisible(selectedRange)
    }
    
   /* @objc func keyboardWillShow(_ notification:Notification) {
        
        if let keyboardSize = (notification.userInfo?[UIKeyboardFrameBeginUserInfoKey] as? NSValue)?.cgRectValue {
           // self.scrollView.contentInset = UIEdgeInsetsMake(0, 0, keyboardSize.height, 0)
            self.scrollView.setContentOffset(CGPoint(x: 0, y: keyboardSize.height), animated: true)
        }
    }*/
    
    @objc func keyboardWillShow( note:NSNotification )
    {
      /*  if let newFrame = (note.userInfo?[ UIKeyboardFrameEndUserInfoKey ] as? NSValue)?.cgRectValue {
            
            var insets: UIEdgeInsets
            
            if self.scrollView.contentInset.bottom == 0 {
                //Show Keyboard
                insets = UIEdgeInsetsMake( 0, 0, newFrame.height, 0 )
            } else {
                //Hide Keyboard -> Reset TableView insets
                insets = UIEdgeInsetsMake( 0, 0, 0, 0 )
            }
            
            self.scrollView.contentInset = insets
            self.scrollView.scrollIndicatorInsets = insets
        }*/
        
        var userInfo = note.userInfo!
        var keyboardFrame:CGRect = (userInfo[UIKeyboardFrameBeginUserInfoKey] as! NSValue).cgRectValue
        print(keyboardFrame)
        if self.keypadType == "textview" {
            
            keyboardFrame.origin.y = keyboardFrame.origin.y + 50
        }
        keyboardFrame = self.view.convert(keyboardFrame, from: nil)
        
        var contentInset:UIEdgeInsets = self.scrollView.contentInset
        contentInset.bottom = keyboardFrame.size.height
        scrollView.contentInset = contentInset
    }
    @objc func myTextFieldDidchange(_ textField: UITextField) {
        
        if self.isBackSpace == false {
            
            // if let amountString = textField.text?.currencyInputFormatting() {
            
            //  textField.text = amountString
            
            
            let currencyFormatter = NumberFormatter()
            currencyFormatter.usesGroupingSeparator = true
            currencyFormatter.numberStyle = .currency
            //currencyFormatter.locale = Locale.current
            currencyFormatter.currencySymbol = ""
            
            
            // We'll force unwrap with the !, if you've got defined data you may need more error checking
            
            var amountStr = textField.text?.replacingOccurrences(of: ",", with: "")
            amountStr = amountStr?.replacingOccurrences(of: "円", with: "")
            
            var priceString:String! = currencyFormatter.string(from: NSNumber(value: Int(amountStr!)!))
            priceString = priceString.replacingOccurrences(of: ".00", with: "")
            
            print(priceString!)
            //0 priceString = priceString.replacingOccurrences(of: ".00", with: "")
            
            textField.text = String(format: "%@円", priceString!)
            
            // }
        }
        else
        {

        }
       
    }
    func textFieldShouldEndEditing(_ textField: UITextField) -> Bool {
        
        textField.text = textField.text?.replacingOccurrences(of: "円", with: "")
        textField.text = String(format: "%@円", textField.text!)

        return true
    }
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        
        let  char = string.cString(using: String.Encoding.utf8)!
        let isBackSpace = strcmp(char, "\\b")

        
        if (isBackSpace == -92) {
            print("Backspace was pressed")
            
            self.isBackSpace = true
        }
        else
        {
            self.isBackSpace = false
        }
        return true
    }
   
    func cleanDollars(_ value: String?) -> String {
        guard value != nil else { return "$0.00" }
        let doubleValue = Double(value!) ?? 0.0
        let formatter = NumberFormatter()
        formatter.currencyCode = "JPY"
        formatter.currencySymbol = "0"
        formatter.minimumFractionDigits = (value!.contains(".00")) ? 0 : 2
        formatter.maximumFractionDigits = 2
        formatter.numberStyle = .currencyAccounting
        return formatter.string(from: NSNumber(value: doubleValue)) ?? "¥\(doubleValue)"
    }
    func textFieldDidEndEditing(_ textField: UITextField) {
        
       // textField.text = textField.text?.replacingOccurrences(of: ".00", with: "")

    }
 
  
    @objc func keyboardWillHide(_ notification:Notification) {
        
       /* if ((notification.userInfo?[UIKeyboardFrameBeginUserInfoKey] as? NSValue)?.cgRectValue) != nil {
            self.scrollView.setContentOffset(CGPoint(x: 0, y: 0), animated: true)
        }*/
        
        let contentInset:UIEdgeInsets = .zero
        self.scrollView.contentInset = contentInset
    }
    
   
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}
extension String {
    
    // formatting text for currency textField
    func currencyInputFormatting() -> String {
        
        var number: NSNumber!
        let formatter = NumberFormatter()
        formatter.numberStyle = .currency
        formatter.currencySymbol = "¥"
        
        var amountWithPrefix = self
        
        // remove from String: "$", ".", ","
        let regex = try! NSRegularExpression(pattern: "[^0-9]", options: .caseInsensitive)
        //let price:Int = regex.numberOfMatches(in: amountWithPrefix, options: NSRegularExpression.MatchingOptions(rawValue: 0), range: NSMakeRange(0, self.count))
        
        amountWithPrefix = regex.stringByReplacingMatches(in: amountWithPrefix, options: NSRegularExpression.MatchingOptions(rawValue: 0), range: NSMakeRange(0, self.count), withTemplate: "")
        
        print(amountWithPrefix)
        
        
        let double = (amountWithPrefix as NSString).doubleValue
        
        print(double)
        
        
        number = NSNumber(value: (double/100))
        print(number!)

        guard number != 0 as NSNumber else {
            return ""
        }
        
       // print(number)
     //   let num = NSNumber(value: 100);
        
       // let numb = number * num

        
        return formatter.string(from: number)!
    }
}
