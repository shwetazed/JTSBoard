//
//  EmployeeDetailViewController.swift
//  JTSBoard
//
//  Created by jts on 09/08/18.
//  Copyright © 2018 jts. All rights reserved.
//

import UIKit
import SwiftyJSON
import Kingfisher

class EmployeeDetailViewController: UIViewController,WebServiceControllerDelegate {

    @IBOutlet weak var imgView: UIImageView!
    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var lblDesignation: UILabel!
    
    @IBOutlet weak var emailBackView: UIView!
    @IBOutlet weak var dobBackView: UIView!
    @IBOutlet weak var phoneBackView: UIView!
    @IBOutlet weak var joiningBackView: UIView!
    @IBOutlet weak var empCodeBackView: UIView!
    @IBOutlet weak var salaryBackView: UIView!
    @IBOutlet weak var addressBackView: UIView!
    
    @IBOutlet weak var lblEmail: UILabel!
    @IBOutlet weak var lblDob: UILabel!
    @IBOutlet weak var lblPhone: UILabel!
    
    @IBOutlet weak var lblJoiningDate: UILabel!
    @IBOutlet weak var lblEmpCode: UILabel!
    @IBOutlet weak var lblSalary: UILabel!
    @IBOutlet weak var lblHomeAddress: UILabel!
    
    @IBOutlet weak var buttonView: UIView!

    var objWebServiceController: WebServiceController?
    var objAddEmployeeViewController: AddEmployeeViewController?
    var objAttendanceInfoViewController: AttendanceInfoViewController?

    
    @IBOutlet weak var addressViewHeight: NSLayoutConstraint!
    var arrEmployeeData = NSDictionary()

    var employeeId:String!

    override func viewDidLoad() {
        super.viewDidLoad()

        self.setBorderArroundView()
    
        
        self.setEmployeeData()
        // Do any additional setup after loading the view.
    }

    func setBorderArroundView()
    {
        self.buttonView.layer.cornerRadius = 10.0
        self.buttonView.clipsToBounds = true
        
        self.imgView.layer.cornerRadius = 10.0
        self.imgView.clipsToBounds = true
        self.imgView.layer.borderWidth = 2.0
        self.imgView.layer.borderColor = UIColor(red: 170/255, green: 171/255, blue: 175/255, alpha: 1.0).cgColor
        
        self.emailBackView.layer.cornerRadius = 5.0
        self.emailBackView.clipsToBounds = true
        self.emailBackView.layer.borderWidth = 1.0
        self.emailBackView.layer.borderColor = UIColor(red: 170/255, green: 171/255, blue: 175/255, alpha: 1.0).cgColor
        
        self.dobBackView.layer.cornerRadius = 5.0
        self.dobBackView.clipsToBounds = true
        self.dobBackView.layer.borderWidth = 1.0
        self.dobBackView.layer.borderColor = UIColor(red: 170/255, green: 171/255, blue: 175/255, alpha: 1.0).cgColor
        
        self.phoneBackView.layer.cornerRadius = 5.0
        self.phoneBackView.clipsToBounds = true
        self.phoneBackView.layer.borderWidth = 1.0
        self.phoneBackView.layer.borderColor = UIColor(red: 170/255, green: 171/255, blue: 175/255, alpha: 1.0).cgColor
        
        self.joiningBackView.layer.cornerRadius = 5.0
        self.joiningBackView.clipsToBounds = true
        self.joiningBackView.layer.borderWidth = 1.0
        self.joiningBackView.layer.borderColor = UIColor(red: 170/255, green: 171/255, blue: 175/255, alpha: 1.0).cgColor
        
        self.empCodeBackView.layer.cornerRadius = 5.0
        self.empCodeBackView.clipsToBounds = true
        self.empCodeBackView.layer.borderWidth = 1.0
        self.empCodeBackView.layer.borderColor = UIColor(red: 170/255, green: 171/255, blue: 175/255, alpha: 1.0).cgColor
        
        self.salaryBackView.layer.cornerRadius = 5.0
        self.salaryBackView.clipsToBounds = true
        self.salaryBackView.layer.borderWidth = 1.0
        self.salaryBackView.layer.borderColor = UIColor(red: 170/255, green: 171/255, blue: 175/255, alpha: 1.0).cgColor
        
        self.addressBackView.layer.cornerRadius = 5.0
        self.addressBackView.clipsToBounds = true
        self.addressBackView.layer.borderWidth = 1.0
        self.addressBackView.layer.borderColor = UIColor(red: 170/255, green: 171/255, blue: 175/255, alpha: 1.0).cgColor
        
       
    }
    
    func setEmployeeData()
    {
      //  ConfigManager.showLoadingHUD(to_view: self.view)
        
        
        self.lblName.text = self.arrEmployeeData["name"] as? String
        self.lblDesignation.text = self.arrEmployeeData["designation"] as? String
        self.lblEmail.text = self.arrEmployeeData["email"] as? String
        self.lblPhone.text = self.arrEmployeeData["phone"] as? String
        self.lblDob.text = self.arrEmployeeData["dob"] as? String
        self.lblSalary.text = self.arrEmployeeData["salary"] as? String
        self.lblEmpCode.text = self.arrEmployeeData["emp_code"] as? String
        self.lblHomeAddress.text = self.arrEmployeeData["address"] as? String
        self.lblJoiningDate.text = self.arrEmployeeData["joining_date"] as? String
        
        if let imgUrl = self.arrEmployeeData["image"] as? String{

            var imgFullUrl:String! = ""
            
            print(imgUrl)
            
            if imgUrl != nil && imgUrl != "" && imgUrl != "<null>"{
                
                imgFullUrl = ConfigManager.gImageUrl + imgUrl
                
                let url = URL(string: imgFullUrl)
                
                self.imgView.kf.setImage(with: url)
            }
            else
            {
                self.imgView.image = UIImage(named: "placeholder")
            }
        }
        else
        {
            self.imgView.image = UIImage(named: "placeholder")
        }
        

    }
    @IBAction func btnEditAction(_ sender: Any) {
        
        self.editEmployee()
    }
    @IBAction func btnDeleteAction(_ sender: Any) {
        
        self.deleteEmployee()
    }
    @IBAction func btnAttandanceInfo(_ sender: Any) {
        
        self.objAttendanceInfoViewController = AttendanceInfoViewController(nibName: "AttendanceInfoViewController", bundle: nil)
        self.objAttendanceInfoViewController?.employeeId = self.employeeId
        self.navigationController?.pushViewController(self.objAttendanceInfoViewController!, animated: true)
        
    }
    
    func deleteEmployee()
    {
        ConfigManager.showLoadingHUD(to_view: self.view)
        
        self.objWebServiceController?.serverParameter(parameters: self.arrEmployeeData as! [String : AnyObject])
        
    }
    func editEmployee()
    {
        
        self.objAddEmployeeViewController = AddEmployeeViewController(nibName: "AddEmployeeViewController", bundle: nil)
        self.objAddEmployeeViewController?.employeeId = self.arrEmployeeData.object(forKey: "id") as! String
        self.objAddEmployeeViewController?.arrEmployeeData = self.arrEmployeeData
        self.navigationController?.pushViewController(self.objAddEmployeeViewController!, animated: true)
    }
    
    // MARK:  Webservice Bar delegate
    
    func serviceResponse(forURl urlString: String, response: JSON) {
        
        ConfigManager.hideLoadingHUD(for_view: self.view)
        
        if !(urlString == "server_error_handle") {
            
           if urlString == "delete_employee"
            {
                let status:String! = String(describing:response["status"])
                
                if status == "success"
                {
                    let alert = UIAlertController(title: "", message: "Employee deleted successfully", preferredStyle: .alert)
                    alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                    self.present(alert, animated: true)
                    
                    self.dismiss(animated: true) {
                        
                        self.navigationController?.popViewController(animated: true)
                    }
                }
            }
            
            
        }
        else {
            let alert = UIAlertController(title: "", message: "Error", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            self.present(alert, animated: true)
        }
    }
    func serviceImageResponse(forURl urlString: String, response: NSDictionary) {
        
    }

    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
