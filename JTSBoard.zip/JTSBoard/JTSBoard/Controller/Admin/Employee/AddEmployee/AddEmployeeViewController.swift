//
//  AddEmployeeViewController.swift
//  JTSBoard
//
//  Created by jts on 09/08/18.
//  Copyright © 2018 jts. All rights reserved.
//

import UIKit
import SwiftyJSON
import Kingfisher

class AddEmployeeViewController: UIViewController,UITextFieldDelegate,WebServiceControllerDelegate,UIImagePickerControllerDelegate,UINavigationControllerDelegate {
    
   
    var objWebServiceController: WebServiceController?

    @IBOutlet weak var scrollView: UIScrollView!
    @IBOutlet weak var btnUploadImage: UIButton!
    @IBOutlet weak var imgUploadImage: UIImageView!
    
    @IBOutlet weak var bottomHeightConstraint: NSLayoutConstraint!
    @IBOutlet weak var txtName: UITextField!
    @IBOutlet weak var txtDob: UITextField!
    @IBOutlet weak var txtPhone: UITextField!
    @IBOutlet weak var txtEmail: UITextField!
    @IBOutlet weak var txtJoiningDate: UITextField!
    @IBOutlet weak var txtEmployeeCode: UITextField!
    @IBOutlet weak var txtDesignation: UITextField!
    @IBOutlet weak var txtSalary: UITextField!
    @IBOutlet weak var txtHomeAddress: UITextField!
    @IBOutlet weak var btnSubmit: UIButton!
    var uploadedImage:String!

    var employeeId:String!
    let picker = UIImagePickerController()
    var arrEmployeeData = NSDictionary()

    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.objWebServiceController = WebServiceController()
        self.objWebServiceController?.delegate = self
        
        self.imgUploadImage.layer.cornerRadius = 10.0
        self.imgUploadImage.clipsToBounds = true
        
        self.btnSubmit.layer.cornerRadius = 5.0
        self.btnSubmit.clipsToBounds = true

        if self.arrEmployeeData.count > 0 {
            
            self.setEmployeeData()

        }
    
        // Do any additional setup after loading the view.
    }
    func setEmployeeData()
    {
        //  ConfigManager.showLoadingHUD(to_view: self.view)
        
        
        self.txtName.text = self.arrEmployeeData["name"] as? String
        self.txtDesignation.text = self.arrEmployeeData["designation"] as? String
        self.txtEmail.text = self.arrEmployeeData["email"] as? String
        self.txtPhone.text = self.arrEmployeeData["phone"] as? String
        self.txtDob.text = self.arrEmployeeData["dob"] as? String
        self.txtSalary.text = self.arrEmployeeData["salary"] as? String
        self.txtEmployeeCode.text = self.arrEmployeeData["emp_code"] as? String
        self.txtHomeAddress.text = self.arrEmployeeData["address"] as? String
        self.txtJoiningDate.text = self.arrEmployeeData["joining_date"] as? String
        
        
        if let imgUrl = self.arrEmployeeData["image"] as? String{

            var imgFullUrl:String! = ""


            if imgUrl != nil && imgUrl != "" && imgUrl != "<null>"{
                
                self.uploadedImage = imgUrl

                imgFullUrl = ConfigManager.gImageUrl + imgUrl
                
                let url = URL(string: imgFullUrl)
                
                self.imgUploadImage.kf.setImage(with: url)
            }
            else
            {
                self.imgUploadImage.image = UIImage(named: "placeholder")
                self.uploadedImage = ""

            }
        }
        else
        {
            self.imgUploadImage.image = UIImage(named: "placeholder")
            self.uploadedImage = ""
        }
       
        
        
    }
    @IBAction func btnUploadImageAction(_ sender: UIButton) {
        
        let alertController = UIAlertController(title: nil, message: "写真をアップする", preferredStyle: .actionSheet)
        
        let photoLibrary = UIAlertAction(title: "図書館から取る", style: .default, handler: { (alert: UIAlertAction!) -> Void in
            //  Do some action here.
            
            self.picker.allowsEditing = false
            self.picker.delegate = self
            self.picker.sourceType = .photoLibrary
            self.picker.mediaTypes = UIImagePickerController.availableMediaTypes(for: .photoLibrary)!
            self.picker.modalPresentationStyle = .popover
            self.present(self.picker, animated: true, completion: nil)
            self.picker.popoverPresentationController?.sourceView = sender
            
        })
        
        let cemaraAction = UIAlertAction(title: "カマラから取る", style: .destructive, handler: { (alert: UIAlertAction!) -> Void in
            //  Do some destructive action here.
            
            if UIImagePickerController.isSourceTypeAvailable(.camera) {
                self.picker.allowsEditing = false
                self.picker.sourceType = UIImagePickerControllerSourceType.camera
                self.picker.cameraCaptureMode = .photo
                self.picker.modalPresentationStyle = .fullScreen
                self.present(self.picker,animated: true,completion: nil)
            }
        })
        
        let cancelAction = UIAlertAction(title: "キャンセル", style: .cancel, handler: { (alert: UIAlertAction!) -> Void in
            //  Do something here upon cancellation.
        })
        
        alertController.addAction(photoLibrary)
        alertController.addAction(cemaraAction)
        alertController.addAction(cancelAction)
        
        if let popoverController = alertController.popoverPresentationController {
            
            popoverController.sourceView = sender
            
            // popoverController.sourceRect = CGRect(x: self.view.bounds.midX, y: self.view.bounds.midY, width: 0, height: 0)
            
        }
        self.present(alertController, animated: true, completion: nil)
        
    }
    
    // MARK: UIimagepicker delegate
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        let img = info[UIImagePickerControllerOriginalImage] as! UIImage
        
        self.imgUploadImage.image = img
        
        dismiss(animated:true, completion: nil)
        
        // print(self.arrServiceList!)
        
        var parameters = [String : AnyObject] ()
        
        parameters["MethodName"] = "upload_image" as AnyObject
        
        parameters["profile_image"] = self.uploadedImage as AnyObject
        
        ConfigManager.showLoadingHUD(to_view: self.view)
        
        print(parameters)
        
        self.objWebServiceController?.serverImageParameter(image: img)
        
    }
    func createDatePicker(textField:UITextField)
    {
        let currentDate = Date()
        var dateComponents = DateComponents()
        dateComponents.month = -3
        let threeMonthAgo = Calendar.current.date(byAdding: dateComponents, to: currentDate)
        
        let datePicker = DatePickerDialog(textColor: .black,
                                          buttonColor: .black,
                                          font: UIFont.boldSystemFont(ofSize: 17),
                                          showCancelButton: true)
        datePicker.show("Select Date",
                        doneButtonTitle: "Done",
                        cancelButtonTitle: "Cancel",
                        minimumDate: threeMonthAgo,
                        maximumDate: currentDate,
                        datePickerMode: .date) { (date) in
                            if let dt = date {
                                let formatter = DateFormatter()
                                formatter.dateFormat = "yyyy-MM-dd"
                                let dobStr:String! = formatter.string(from: dt)
                                if textField == self.txtDob
                                {
                                    self.txtDob.text = dobStr

                                }
                                else
                                {
                                    self.txtJoiningDate.text = dobStr

                                }
                                
                            }
        }
    }

    @IBAction func btnSubmitAction(_ sender: UIButton) {
        
        if self.txtName.text?.count == 0 {
            
            let alert = UIAlertController(title: "", message: "Please enter name", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            self.present(alert, animated: true)
            
            return
        }
        if self.txtDob.text?.count == 0 {
            
            let alert = UIAlertController(title: "", message: "Please enter date of birth", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            self.present(alert, animated: true)
            
            return
        }
        if self.txtPhone.text?.count == 0 {
            
            let alert = UIAlertController(title: "", message: "Please enter phone", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            self.present(alert, animated: true)
            
            return
        }
        if self.txtEmail.text?.count == 0 {
            
            let alert = UIAlertController(title: "", message: "Please enter email address", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            self.present(alert, animated: true)
            
            return
        }
        if self.txtJoiningDate.text?.count == 0 {
            
            let alert = UIAlertController(title: "", message: "Please enter joining date", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            self.present(alert, animated: true)
            
            return
        }
        if self.txtEmployeeCode.text?.count == 0 {
            
            let alert = UIAlertController(title: "", message: "Please enter employee code", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            self.present(alert, animated: true)
            
            return
        }
        if self.txtDesignation.text?.count == 0 {
            
            let alert = UIAlertController(title: "", message: "Please enter designation", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            self.present(alert, animated: true)
            
            return
        }
        if self.txtSalary.text?.count == 0 {
            
            let alert = UIAlertController(title: "", message: "Please enter salary", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            self.present(alert, animated: true)
            
            return
        }
        if self.txtHomeAddress.text?.count == 0 {
            
            let alert = UIAlertController(title: "", message: "Please enter home address", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            self.present(alert, animated: true)
            
            return
        }
        
        self.saveEmployeeData()
    }
    // MARK:  Webservice  method

   
    func saveEmployeeData() {
        
        ConfigManager.showLoadingHUD(to_view: self.view)
        
        var parameters = [String : AnyObject] ()
        
        parameters["MethodName"] = "add_employee" as AnyObject
        parameters["user_id"] = ConfigManager.gUserId as AnyObject
        parameters["name"] = self.txtName.text as AnyObject
        parameters["dob"] = self.txtDob.text as AnyObject
        parameters["phone"] = self.txtPhone.text as AnyObject
        parameters["email"] = self.txtEmail.text as AnyObject
        parameters["joining_date"] = self.txtJoiningDate.text as AnyObject
        parameters["emp_code"] = self.txtEmployeeCode.text as AnyObject
        parameters["designation"] = self.txtDesignation.text as AnyObject
        parameters["salary"] = self.txtSalary.text as AnyObject
        parameters["address"] = self.txtHomeAddress.text as AnyObject
        parameters["image"] = self.uploadedImage as AnyObject

        if self.employeeId != nil || self.employeeId != "" {
            
            parameters["id"] = self.employeeId as AnyObject

        }
        
        self.objWebServiceController?.serverParameter(parameters: parameters)
        
        
    }
    // pragma UItextfield delegate
 
    func scrollView(toCenterOfScreen theView: UIView, textfield: UITextField) {
        let viewCenterY: CGFloat = theView.center.y
        let applicationFrame: CGRect = UIScreen.main.bounds
        var availableHeight: CGFloat
        availableHeight = applicationFrame.size.height - 150
        
        var y: CGFloat = viewCenterY - availableHeight / 2.0
        if y < 0 {
            y = 0
        }
        scrollView.setContentOffset(CGPoint(x: 0, y: y), animated: true)
    }
    
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        
        if textField == self.txtDob || textField == self.txtJoiningDate{
            
            textField.resignFirstResponder()
            self.createDatePicker(textField: textField)
        }
        else
        {
            scrollView(toCenterOfScreen: textField, textfield: textField)

        }
        return true
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        
        textField.resignFirstResponder()
        UIView.beginAnimations("anim", context: nil)
        UIView.setAnimationBeginsFromCurrentState(true)
        UIView.setAnimationDuration(0.25)
        scrollView.setContentOffset(CGPoint(x: 0, y: 0), animated: true)
        UIView.commitAnimations()
        
        return true
    }
    
    // Mark WebService  delegate

    func serviceResponse(forURl urlString: String, response: JSON) {
        
        ConfigManager.hideLoadingHUD(for_view: self.view)
        
        if !(urlString == "server_error_handle") {
            
            if urlString == "add_employee"
            {
                let status:String! = String(describing:response["status"])

                if status == "success"
                {
                    let alert = UIAlertController(title: "", message: "Employee added successfully", preferredStyle: .alert)
                    alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                    self.present(alert, animated: true)
                    
                    self.dismiss(animated: true) {
                        
                        self.navigationController?.popViewController(animated: true)

                    }
                }

            }
            
        }
        else {
            let alert = UIAlertController(title: "", message: "Error", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            self.present(alert, animated: true)
        }
    }
    
    func serviceImageResponse(forURl urlString: String, response: NSDictionary) {
        
        ConfigManager.hideLoadingHUD(for_view: self.view)
        
        if !(urlString == "server_error_handle") {
            
            if urlString == "upload_note_image"
            {
                if let resData = response["response_data"] {
                    
                    let dict:NSDictionary = resData as! NSDictionary
                    
                    let image:String! = String(describing:dict["image"]!)
                    
                    self.uploadedImage = image!
                    
                    print(self.uploadedImage!);
                    
                }
            }
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
