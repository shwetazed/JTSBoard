//
//  AttendanceViewController.swift
//  JTSBoard
//
//  Created by jts on 09/08/18.
//  Copyright © 2018 jts. All rights reserved.
//

import UIKit
import SwiftyJSON

class AttendanceViewController: UIViewController, WebServiceControllerDelegate {

    @IBOutlet weak var btnThumb: UIButton!
    var objWebServiceController: WebServiceController?

   
    override func viewDidLoad() {
        super.viewDidLoad()

        self.objWebServiceController = WebServiceController()
        self.objWebServiceController?.delegate = self
        // Do any additional setup after loading the view.
    }
    @IBAction func btnThumbAction(_ sender: UIButton) {
        
        ConfigManager.showLoadingHUD(to_view: self.view)
        
        var parameters = [String : AnyObject] ()
        
        parameters["MethodName"] = "add_attendance" as AnyObject
       // parameters["touch_id"] = "d0659668c65ede320493e66e0ae4c370f20703d9" as AnyObject
        parameters["touch_id"] = "257160e23ea91160b4e1dcc52c5518e0a9ce0f3a" as AnyObject
        
        parameters["user_id"] = ConfigManager.gUserId as AnyObject

        self.objWebServiceController?.serverParameter(parameters: parameters)
    }
    
    // MARK:  Webservice Bar delegate

    func serviceResponse(forURl urlString: String, response: JSON) {
        
        ConfigManager.hideLoadingHUD(for_view: self.view)
        
        if !(urlString == "server_error_handle") {
            
            if urlString == "add_attendance"
            {
                let status:String! = String(describing:response["status"])
                let msg:String! = String(describing:response["msg"])

                if status == "success"
                {
                    let alert = UIAlertController(title: "", message: msg, preferredStyle: .alert)
                    alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                    self.present(alert, animated: true)
                    
                    self.dismiss(animated: true) {
                        
                        self.navigationController?.popViewController(animated: true)
                    }
                    
                }
            }
            
        }
        else {
            let alert = UIAlertController(title: "", message: "Error", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            self.present(alert, animated: true)
        }
    }
    func serviceImageResponse(forURl urlString: String, response: NSDictionary) {
        
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
