//
//  DashboardViewController.swift
//  JTSBoard
//
//  Created by jts on 10/07/18.
//  Copyright © 2018 jts. All rights reserved.
//

import UIKit

class DashboardViewController: UIViewController {

    @IBOutlet weak var btnMyShop: UIButton!
    @IBOutlet weak var btnForm: UIButton!
    @IBOutlet weak var btnCustomerList: UIButton!
    @IBOutlet weak var btnEmployee: UIButton!
    @IBOutlet weak var btnAttendance: UIButton!
    
    @IBOutlet weak var btnMyShopIpad: UIButton!
    @IBOutlet weak var btnFormIpad: UIButton!
    @IBOutlet weak var btnCustomerListIpad: UIButton!
    @IBOutlet weak var btnEmployeeIpad: UIButton!
    @IBOutlet weak var btnAttendanceIpad: UIButton!
    
    @IBOutlet weak var scrollPortrait: UIScrollView!
    @IBOutlet weak var scrollLandscape: UIScrollView!
    @IBOutlet weak var viewLandscape: UIView!
    @IBOutlet weak var viewPortrait: UIView!

    
    var objMainFromViewController: MainFromViewController?
    var objCustomerListViewController: CustomerListViewController?
    var objSalonProfileViewController: SalonProfileViewController?
    var objEmployeeListViewController: EmployeeListViewController?
    var objAttendanceViewController: AttendanceViewController?

    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.view.addSubview(self.viewPortrait)
        self.view.addSubview(self.viewLandscape)
      
       // print(UIApplication.shared.statusBarOrientation.isPortrait)
       // print(UIApplication.shared.statusBarOrientation.isLandscape)

       
        self.navigationController?.navigationBar.backgroundColor = UIColor(red: 163/255, green: 125/255, blue: 30/255, alpha: 1.0)
        self.navigationController?.navigationBar.tintColor =  UIColor.black

        self.navigationItem.leftBarButtonItem = UIBarButtonItem.init(title: "ログアウト", style: UIBarButtonItemStyle.done, target: self, action: #selector(btnLogoutAction))
        
        self.setLayout()

       // NotificationCenter.default.addObserver(self, selector: #selector(AppDelegate.rotated), name: NSNotification.Name.UIDeviceOrientationDidChange, object: nil)

        // Do any additional setup after loading the view.
    }
    override func viewWillAppear(_ animated: Bool) {
        
        self.viewLandscape.frame = self.view.frame
        self.viewPortrait.frame = self.view.frame
        
        if UIApplication.shared.statusBarOrientation.isPortrait == true
        {
            self.viewPortrait.isHidden = false
            self.viewLandscape.isHidden = true
        }
        else
        {
            self.viewPortrait.isHidden = true
            self.viewLandscape.isHidden = false
        }

    }
    func setLayout()
    {
        self.btnMyShop.layer.cornerRadius = 10.0
        self.btnMyShop.clipsToBounds = true
        
        self.btnForm.layer.cornerRadius = 10.0
        self.btnForm.clipsToBounds = true
        
        self.btnCustomerList.layer.cornerRadius = 10.0
        self.btnCustomerList.clipsToBounds = true
        
        self.btnEmployee.layer.cornerRadius = 10.0
        self.btnEmployee.clipsToBounds = true
        
        self.btnAttendance.layer.cornerRadius = 10.0
        self.btnAttendance.clipsToBounds = true
        self.btnAttendance.layer.borderColor = (UIColor(red: 184/255, green: 134/255, blue: 30/255, alpha: 1.0)).cgColor
        self.btnAttendance.layer.borderWidth = 1.0
        
        self.btnMyShopIpad.layer.cornerRadius = 10.0
        self.btnMyShopIpad.clipsToBounds = true

        self.btnFormIpad.layer.cornerRadius = 10.0
        self.btnFormIpad.clipsToBounds = true

        self.btnCustomerListIpad.layer.cornerRadius = 10.0
        self.btnCustomerListIpad.clipsToBounds = true

        self.btnEmployeeIpad.layer.cornerRadius = 10.0
        self.btnEmployeeIpad.clipsToBounds = true

        self.btnAttendanceIpad.layer.cornerRadius = 10.0
        self.btnAttendanceIpad.clipsToBounds = true
        self.btnAttendanceIpad.layer.borderColor = (UIColor(red: 184/255, green: 134/255, blue: 30/255, alpha: 1.0)).cgColor
        self.btnAttendanceIpad.layer.borderWidth = 1.0
    }
    @objc func btnLogoutAction()
    {
       ConfigManager.sharedAppDelegate.logoutFromApp()
    }
   
    @IBAction func btnMyShopAction(_ sender: UIButton) {

        self.objSalonProfileViewController = SalonProfileViewController(nibName: "SalonProfileViewController", bundle: nil)
        self.navigationController?.pushViewController(self.objSalonProfileViewController!, animated: true)
    }
    @IBAction func btnFormAction(_ sender: UIButton) {
        
        self.objMainFromViewController = MainFromViewController(nibName: "MainFromViewController", bundle: nil)
        self.navigationController?.pushViewController(self.objMainFromViewController!, animated: true)
    }
   
    @IBAction func btnCustomerListAction(_ sender: UIButton) {
        
        self.objCustomerListViewController = CustomerListViewController(nibName: "CustomerListViewController", bundle: nil)
        self.navigationController?.pushViewController(self.objCustomerListViewController!, animated: true)
    }
  
    @IBAction func btnEmployeeAction(_ sender: UIButton) {
        
        
//        let alert = UIAlertController(title: "", message: "近日公開", preferredStyle: .alert)
//        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
//        self.present(alert, animated: true)
        self.objEmployeeListViewController = EmployeeListViewController(nibName: "EmployeeListViewController", bundle: nil)
        self.navigationController?.pushViewController(self.objEmployeeListViewController!, animated: true)
    }
    @IBAction func btnAttendanceAction(_ sender: UIButton) {
        
        self.objAttendanceViewController = AttendanceViewController(nibName: "AttendanceViewController", bundle: nil)
        self.navigationController?.pushViewController(self.objAttendanceViewController!, animated: true)
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    override func viewWillTransition(to size: CGSize, with coordinator: UIViewControllerTransitionCoordinator) {
        if UIDevice.current.orientation.isLandscape {
            print("Landscape")
            
            self.viewLandscape.isHidden = false
            self.viewPortrait.isHidden = true
            self.viewLandscape.frame = self.view.frame

            
        } else {
            print("Portrait")
            self.viewPortrait.frame = self.view.frame

            self.viewLandscape.isHidden = true
            self.viewPortrait.isHidden = false

        }
    }
    override func didRotate(from fromInterfaceOrientation: UIInterfaceOrientation) {
        var text=""
        switch UIDevice.current.orientation{
        case .portrait:
            text="Portrait"
        case .portraitUpsideDown:
            text="PortraitUpsideDown"
        case .landscapeLeft:
            text="LandscapeLeft"
        case .landscapeRight:
            text="LandscapeRight"
        default:
            text="Another"
        }
        NSLog("You have moved: \(text)")
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
