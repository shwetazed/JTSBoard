//
//  LoginViewController.swift
//  SalonatApp
//
//  Created by Apple on 05/04/18.
//  Copyright © 2018 Apple. All rights reserved.
//

import UIKit
import Alamofire
import MBProgressHUD
import SwiftyJSON


class LoginViewController: UIViewController, UITextFieldDelegate,WebServiceControllerDelegate {

    var socialDic = [String : String] ()
    var checkForgotAlert : String!
    var checkLoginType : String!
    var checkLoginCount : Int!

    @IBOutlet weak var txtEmail: FloatLabelTextField!
    @IBOutlet weak var txtPass: FloatLabelTextField!
    @IBOutlet weak var btnLogin: UIButton!
    @IBOutlet weak var scrollView: UIScrollView!
    @IBOutlet weak var btnSignUp: UIButton!
    
    var objRegistrationViewController : RegistrationViewController?
    var objDashboardViewController : DashboardViewController?

    var objWebServiceController: WebServiceController?

    var navigation: TopNavigationView?
    
    func setNavigation() {
        
        if ConfigManager.DeviceType.IS_IPHONE_X {
            
            navigation = TopNavigationView(frame: CGRect(x: 0, y: 0, width: (ConfigManager.sharedAppDelegate.window?.frame.size.width)!, height: 80), withRef: self, navController: navigationController!, vController: view)

        }
        else
        {
            navigation = TopNavigationView(frame: CGRect(x: 0, y: 0, width: (ConfigManager.sharedAppDelegate.window?.frame.size.width)!, height: 60), withRef: self, navController: navigationController!, vController: view)

        }
        navigation?.lblTitle?.isHidden = false
        
        navigation?.lblTitle?.text = "Login"
      
        
        var mImg: UIImage? = nil
        
        mImg = ConfigManager.filledImageFrom(source: UIImage(named: "back_arrow")!, fillColor: UIColor.white)
        navigation?.menuButton?.setImage(mImg, for: .normal)
        navigation?.menuButton?.addTarget(self, action: #selector(self.btnBackPressed), for: .touchUpInside)
        
        navigation?.btnTV?.isHidden = true
        navigation?.menuButton?.isHidden = true


        view.addSubview(navigation!)
        
       
        
    }
    @IBAction func btnBackPressed(_ sender: Any) {
        
        if ConfigManager.isLoginAtStart == false
        {
            self.navigationController?.popViewController(animated: true)
        }
        
    }
    @IBAction func btnSkipPressed(_ sender: Any) {
        
        ConfigManager.isSkip = true
       // ConfigManager.sharedAppDelegate.createMenuView()
    }
    @IBAction func btnLoginAction(_ sender: UIButton) {
        
        //ConfigManager.sharedAppDelegate.createMenuView()

        if self.txtEmail.text?.count == 0 {
            
            let alert = UIAlertController(title: "", message: ConfigManager.ALERT_MSG_BLANK_EMAIL, preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            self.present(alert, animated: true)
            
            return
        }
      
        else if self.txtPass.text?.count == 0 {
            
            let alert = UIAlertController(title: "", message: ConfigManager.ALERT_MSG_BLANK_PASSWORD, preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            self.present(alert, animated: true)
           
            return
        }
        
        setLoginData(self.txtEmail.text!, password: self.txtPass.text!)
    }
    
    func setLoginData(_ email: String, password: String) {
        
        
         ConfigManager.showLoadingHUD(to_view: self.view)
        var parameters = [String : AnyObject] ()
        parameters["email"] = email as AnyObject
        parameters["password"] = password as AnyObject
        parameters["MethodName"] = "login" as AnyObject
       
        self.objWebServiceController?.serverParameter(parameters: parameters)

    }
   
    
   
    @IBAction func btnSignUpAction(_ sender: UIButton) {
        
        self.objRegistrationViewController = RegistrationViewController(nibName: "RegistrationViewController", bundle: nil)
        self.navigationController?.pushViewController(self.objRegistrationViewController!, animated: true)
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.navigationItem.title = "ログイン"
        
        self.navigationController?.navigationBar.tintColor = UIColor.black
        
        self.btnLogin.layer.cornerRadius = 5.0
        self.btnLogin.clipsToBounds = true

        self.btnSignUp.layer.cornerRadius = 5.0
        self.btnSignUp.clipsToBounds = true

        self.objWebServiceController = WebServiceController()
        self.objWebServiceController?.delegate = self
        
        let tapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(self.handleTapFrom))
        view.addGestureRecognizer(tapGestureRecognizer)
        
        //AD7D1E
        
        self.navigationController?.navigationBar.backgroundColor = UIColor(red: 163/255, green: 125/255, blue: 30/255, alpha: 1.0)
        self.navigationController?.navigationBar.tintColor =  UIColor(red: 163/255, green: 125/255, blue: 30/255, alpha: 1.0)

        self.setValuesFromUserDefaults()
        
        print(ConfigManager.gUserId!)
        
      
    }
    
    func setValuesFromUserDefaults()
    {
       
        if UserDefaults.standard.object(forKey: "USERID") != nil {
            
            if UserDefaults.standard.object(forKey: "EMAIL") != nil {
                
                ConfigManager.gEmail = UserDefaults.standard.object(forKey: "EMAIL") as! String
                
            }
            ConfigManager.gUserId = UserDefaults.standard.object(forKey: "USERID") as! String
            
            ConfigManager.sharedAppDelegate.setLandingPage()
          
            
        }
       
       
        
      
    }
    
    
    @objc func handleTapFrom(recognizer : UITapGestureRecognizer ) {
        
       
    }
   
    
    // MARK: ------------Delegate-----------------
    // MARK: TextFieldDelegate
    
    func resignTextField() {
        self.txtEmail.resignFirstResponder()
        self.txtPass.resignFirstResponder()
    }
    

    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        
    }
    func scrollView(toCenterOfScreen theView: UIView, textfield: UITextField) {
        let viewCenterY: CGFloat = theView.center.y
        let applicationFrame: CGRect = UIScreen.main.bounds
        var availableHeight: CGFloat
        availableHeight = applicationFrame.size.height - 150
       
        var y: CGFloat = viewCenterY - availableHeight / 2.0
        if y < 0 {
            y = 0
        }
        scrollView.setContentOffset(CGPoint(x: 0, y: y), animated: true)
    }
    
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        scrollView(toCenterOfScreen: textField, textfield: textField)
        return true
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        
     
            textField.resignFirstResponder()
            UIView.beginAnimations("anim", context: nil)
            UIView.setAnimationBeginsFromCurrentState(true)
            UIView.setAnimationDuration(0.25)
            scrollView.setContentOffset(CGPoint(x: 0, y: 0), animated: true)
            UIView.commitAnimations()
        return true
    }
   
    // MARK: Webservice delegate

   
    func serviceResponse(forURl urlString: String, response: JSON) {
        
        ConfigManager.hideLoadingHUD(for_view: self.view)
        
        if !(urlString == "server_error_handle") {
            
            let status:String! = String(describing:response["status"])
            let msg:String! = String(describing:response["msg"])

            if status != nil
            {
                if status == "error"
                {
                    self.txtEmail.text = ""
                    self.txtPass.text = ""
                    
                    let alert = UIAlertController(title: "", message: msg, preferredStyle: .alert)
                    alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
                    self.present(alert, animated: true)
                    
                }
                else
                {
                    let userId:String! = String(describing:response["user_id"])
                    let isForm:String! = String(describing:response["is_form"])

                    if userId != nil
                    {
                        let isAdmin:String! = String(describing:response["is_admin"])

                        ConfigManager.gUserId = userId!
                        ConfigManager.gFormNumber = isForm!
                        ConfigManager.gEmail = self.txtEmail.text!
                        ConfigManager.gIsAdmin = isAdmin

                        UserDefaults.standard.set(ConfigManager.gUserId, forKey: "USERID")
                        UserDefaults.standard.set(ConfigManager.gFormNumber, forKey: "FORMNUM")
                        UserDefaults.standard.set(ConfigManager.gEmail, forKey: "EMAIL")
                        UserDefaults.standard.set(ConfigManager.gIsAdmin, forKey: "ISADMIN")

                        ConfigManager.sharedAppDelegate.setLandingPage()
                        
                        //self.objDashboardViewController = DashboardViewController(nibName: "DashboardViewController", bundle: nil)
                        //self.navigationController?.pushViewController(self.objDashboardViewController!, animated: true)
                        
                        self.txtEmail.text = ""
                        self.txtPass.text = ""
                    }
                   

                }
                
            }
            
        }
        else {
            let alert = UIAlertController(title: "", message: "Error", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            self.present(alert, animated: true)
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    func serviceImageResponse(forURl urlString: String, response: NSDictionary) {
        
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
